package com.example.gemma4local

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class FileStore(private val context: Context) {
    private val modelDir: File by lazy { File(context.filesDir, "models").apply { mkdirs() } }
    private val imageDir: File by lazy { File(context.cacheDir, "images").apply { mkdirs() } }

    fun defaultModelFile(): File = File(modelDir, "gemma-4-E2B-it.litertlm")

    suspend fun copyModelFromUri(uri: Uri): File = withContext(Dispatchers.IO) {
        val name = queryDisplayName(uri)?.takeIf { it.endsWith(".litertlm", ignoreCase = true) }
            ?: "gemma-local-model.litertlm"
        val target = File(modelDir, sanitizeFileName(name))
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "モデルファイルを開けませんでした。" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        target
    }

    suspend fun copyImageFromUri(uri: Uri): File = withContext(Dispatchers.IO) {
        val target = File(imageDir, "selected-image-${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "画像ファイルを開けませんでした。" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        target
    }

    suspend fun downloadModel(
        url: String,
        bearerToken: String?,
        onProgress: suspend (Int) -> Unit,
    ): File = withContext(Dispatchers.IO) {
        val target = defaultModelFile()
        val tmp = File(modelDir, "${target.name}.download")

        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 120_000
            requestMethod = "GET"
            if (!bearerToken.isNullOrBlank()) {
                setRequestProperty("Authorization", "Bearer $bearerToken")
            }
        }

        try {
            val code = connection.responseCode
            require(code in 200..299) { "ダウンロード失敗: HTTP $code" }
            val total = connection.contentLengthLong.coerceAtLeast(1L)
            var readTotal = 0L
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

            connection.inputStream.use { input ->
                tmp.outputStream().use { output ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        readTotal += read
                        val percent = ((readTotal * 100) / total).toInt().coerceIn(0, 100)
                        onProgress(percent)
                    }
                }
            }

            if (target.exists()) target.delete()
            require(tmp.renameTo(target)) { "モデルファイルの保存に失敗しました。" }
            onProgress(100)
            target
        } finally {
            connection.disconnect()
            if (tmp.exists() && !target.exists()) tmp.delete()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        val projection = arrayOf(android.provider.OpenableColumns.DISPLAY_NAME)
        return runCatching {
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && index >= 0) cursor.getString(index) else null
            }
        }.getOrNull()
    }

    private fun sanitizeFileName(input: String): String = input.replace(Regex("[^A-Za-z0-9._-]"), "_")
}
