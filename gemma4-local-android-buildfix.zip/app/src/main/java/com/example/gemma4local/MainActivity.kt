package com.example.gemma4local

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var fileStore: FileStore
    private lateinit var runner: OnDeviceGemmaRunner

    private lateinit var statusText: TextView
    private lateinit var modelPathText: TextView
    private lateinit var imagePathText: TextView
    private lateinit var chatLog: TextView
    private lateinit var modelUrlInput: EditText
    private lateinit var hfTokenInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var gpuSwitch: Switch
    private lateinit var sendButton: Button
    private lateinit var loadButton: Button

    private var selectedModelPath: String? = null
    private var selectedImagePath: String? = null

    private val prefs by lazy { getSharedPreferences("gemma4-local", MODE_PRIVATE) }

    private val pickModelLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            runCatching {
                setBusy(true, "モデルをアプリ内ストレージへコピー中…")
                fileStore.copyModelFromUri(uri)
            }.onSuccess { file ->
                saveModelPath(file.absolutePath)
                appendLog("\n[system] モデルを選択しました: ${file.name}\n")
                setBusy(false, "モデルを選択済みです。読み込みボタンを押してください。")
            }.onFailure { error ->
                setBusy(false, "モデルコピーに失敗しました。")
                toast(error.message ?: "モデルコピーに失敗しました。")
            }
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            runCatching {
                setBusy(true, "画像をコピー中…")
                fileStore.copyImageFromUri(uri)
            }.onSuccess { file ->
                selectedImagePath = file.absolutePath
                imagePathText.text = "画像: ${file.name}"
                appendLog("\n[system] 画像を選択しました: ${file.name}\n")
                setBusy(false, "画像を選択済みです。質問を入力してください。")
            }.onFailure { error ->
                setBusy(false, "画像コピーに失敗しました。")
                toast(error.message ?: "画像コピーに失敗しました。")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fileStore = FileStore(this)
        runner = OnDeviceGemmaRunner(this)
        selectedModelPath = prefs.getString(KEY_MODEL_PATH, null)
        setContentView(createUi())
        updateModelText()
    }

    override fun onDestroy() {
        runner.close()
        super.onDestroy()
    }

    private fun createUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
            )
        }

        root.addView(TextView(this).apply {
            text = "Gemma 4 Local Vision Chat"
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "APIキーなし・サーバーなしで、.litertlm モデルを端末内実行します。"
            textSize = 14f
            setPadding(0, 4, 0, 16)
        })

        statusText = TextView(this).apply {
            text = "未読み込み"
            textSize = 14f
        }
        root.addView(statusText)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progressBar, matchWrap())

        modelPathText = TextView(this).apply {
            textSize = 12f
            setPadding(0, 8, 0, 8)
        }
        root.addView(modelPathText)

        val modelButtonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modelButtonRow.addView(button("モデル選択") {
            pickModelLauncher.launch(arrayOf("application/octet-stream", "*/*"))
        }, rowWeight())

        loadButton = button("読み込み") { loadModel() }
        modelButtonRow.addView(loadButton, rowWeight())
        root.addView(modelButtonRow)

        gpuSwitch = Switch(this).apply {
            text = "GPUを使う（Gemma 4 画像認識は推奨）"
            isChecked = prefs.getBoolean(KEY_USE_GPU, true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(KEY_USE_GPU, checked).apply() }
        }
        root.addView(gpuSwitch)

        modelUrlInput = EditText(this).apply {
            hint = "任意: .litertlm の直接ダウンロードURL"
            singleLine()
        }
        root.addView(modelUrlInput, matchWrap())

        hfTokenInput = EditText(this).apply {
            hint = "任意: Hugging Face token（必要な場合のみ）"
            singleLine()
        }
        root.addView(hfTokenInput, matchWrap())

        root.addView(button("URLからモデルをダウンロード") { downloadModel() }, matchWrap())

        imagePathText = TextView(this).apply {
            text = "画像: 未選択"
            textSize = 12f
            setPadding(0, 12, 0, 4)
        }
        root.addView(imagePathText)

        val imageRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        imageRow.addView(button("画像選択") { pickImageLauncher.launch("image/*") }, rowWeight())
        imageRow.addView(button("画像クリア") {
            selectedImagePath = null
            imagePathText.text = "画像: 未選択"
        }, rowWeight())
        root.addView(imageRow)

        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            setPadding(0, 12, 0, 12)
        }
        chatLog = TextView(this).apply {
            text = "[system] モデルファイルを選択またはダウンロードしてから、読み込みを押してください。\n"
            textSize = 15f
            setTextIsSelectable(true)
        }
        scrollView.addView(chatLog)
        root.addView(scrollView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f,
        ))

        promptInput = EditText(this).apply {
            hint = "質問を入力（例: この画像に何が写っていますか？）"
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
        }
        root.addView(promptInput, matchWrap())

        val chatButtonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sendButton = button("送信") { sendPrompt() }
        chatButtonRow.addView(sendButton, rowWeight())
        chatButtonRow.addView(button("会話リセット") { resetChat() }, rowWeight())
        root.addView(chatButtonRow)

        return root
    }

    private fun loadModel() {
        val modelPath = selectedModelPath
        if (modelPath.isNullOrBlank() || !File(modelPath).exists()) {
            toast("先に .litertlm モデルファイルを選択してください。")
            return
        }

        lifecycleScope.launch {
            runCatching {
                setBusy(true, "モデルを読み込み中…初回は時間がかかります。")
                runner.loadModel(modelPath = modelPath, useGpu = gpuSwitch.isChecked)
            }.onSuccess {
                setBusy(false, "モデル読み込み完了。オンデバイスで実行できます。")
                appendLog("\n[system] モデル読み込み完了: ${File(modelPath).name}\n")
            }.onFailure { error ->
                setBusy(false, "モデル読み込みに失敗しました。CPUに切り替えると動く場合があります。")
                appendLog("\n[error] ${error.message ?: error.javaClass.simpleName}\n")
            }
        }
    }

    private fun downloadModel() {
        val url = modelUrlInput.text.toString().trim()
        if (url.isBlank()) {
            toast("ダウンロードURLを入力してください。")
            return
        }

        lifecycleScope.launch {
            runCatching {
                progressBar.visibility = View.VISIBLE
                setBusy(true, "モデルをダウンロード中…")
                fileStore.downloadModel(
                    url = url,
                    bearerToken = hfTokenInput.text.toString().trim().ifBlank { null },
                ) { percent ->
                    withContext(Dispatchers.Main) {
                        progressBar.progress = percent
                        statusText.text = "モデルをダウンロード中… $percent%"
                    }
                }
            }.onSuccess { file ->
                progressBar.visibility = View.GONE
                saveModelPath(file.absolutePath)
                appendLog("\n[system] モデルを保存しました: ${file.absolutePath}\n")
                setBusy(false, "ダウンロード完了。読み込みボタンを押してください。")
            }.onFailure { error ->
                progressBar.visibility = View.GONE
                setBusy(false, "ダウンロードに失敗しました。")
                appendLog("\n[error] ${error.message ?: error.javaClass.simpleName}\n")
            }
        }
    }

    private fun sendPrompt() {
        val prompt = promptInput.text.toString().trim()
        if (prompt.isBlank()) {
            toast("質問を入力してください。")
            return
        }
        if (!runner.isLoaded) {
            toast("先にモデルを読み込んでください。")
            return
        }

        val imagePath = selectedImagePath
        appendLog("\n[user] $prompt\n")
        if (!imagePath.isNullOrBlank()) appendLog("[image] ${File(imagePath).name}\n")
        appendLog("[assistant] ")
        promptInput.setText("")
        sendButton.isEnabled = false
        statusText.text = "生成中…"

        lifecycleScope.launch {
            runCatching {
                runner.sendMessage(prompt, imagePath) { partial ->
                    withContext(Dispatchers.Main) { appendLog(partial) }
                }
            }.onFailure { error ->
                appendLog("\n[error] ${error.message ?: error.javaClass.simpleName}\n")
            }
            appendLog("\n")
            statusText.text = "待機中"
            sendButton.isEnabled = true
        }
    }

    private fun resetChat() {
        lifecycleScope.launch {
            if (runner.isLoaded) {
                runCatching { runner.resetConversation() }
                    .onFailure { appendLog("\n[error] ${it.message ?: it.javaClass.simpleName}\n") }
            }
            chatLog.text = "[system] 会話をリセットしました。\n"
            selectedImagePath = null
            imagePathText.text = "画像: 未選択"
            statusText.text = if (runner.isLoaded) "待機中" else "未読み込み"
        }
    }

    private fun setBusy(busy: Boolean, status: String) {
        statusText.text = status
        loadButton.isEnabled = !busy
        sendButton.isEnabled = !busy
    }

    private fun appendLog(text: String) {
        chatLog.append(text)
    }

    private fun saveModelPath(path: String) {
        selectedModelPath = path
        prefs.edit().putString(KEY_MODEL_PATH, path).apply()
        updateModelText()
    }

    private fun updateModelText() {
        modelPathText.text = selectedModelPath?.let { "モデル: $it" } ?: "モデル: 未選択"
    }

    private fun button(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT,
    )

    private fun rowWeight(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        0,
        LinearLayout.LayoutParams.WRAP_CONTENT,
        1f,
    )

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        private const val KEY_MODEL_PATH = "model_path"
        private const val KEY_USE_GPU = "use_gpu"
    }
}
