plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gemma4local"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.gemma4local"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        getByName("debug")
    }

    buildTypes {
        debug {
            isDebuggable = true
        }
        release {
            // Demo setting: signs release artifacts with the debug key so GitHub Actions can produce APK/AAB.
            // Replace with a real release signingConfig before publishing to Google Play.
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    kotlinOptions {
        jvmTarget = "21"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // LiteRT-LM runs Gemma-family .litertlm models on-device.
    // latest.release tracks Google's current Maven release; pin a specific version for production.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.10.2")
}
