# Keep LiteRT-LM JNI-facing classes.
-keep class com.google.ai.edge.litertlm.** { *; }
