package com.example.gemma4vision

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.ai.edge.litertlm.LlmInference
import com.google.ai.edge.litertlm.LlmInferenceOptions
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : AppCompatActivity() {

    // モデルのパス（adb push で転送したファイル）
    // adb push gemma-4-E2B-it.litertlm /data/local/tmp/llm/
    private val MODEL_PATH = "/data/local/tmp/llm/gemma-4-E2B-it.litertlm"

    private lateinit var imageView: ImageView
    private lateinit var resultText: TextView
    private lateinit var promptInput: EditText
    private lateinit var analyzeButton: Button
    private lateinit var selectImageButton: Button
    private lateinit var takePicButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var promptSpinner: Spinner
    private lateinit var statusText: TextView

    private var selectedBitmap: Bitmap? = null
    private var cameraImageUri: Uri? = null
    private var llmInference: LlmInference? = null

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // ギャラリーから画像選択
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, it)
            selectedBitmap = resizeBitmap(bitmap, 768)
            imageView.setImageBitmap(selectedBitmap)
            analyzeButton.isEnabled = llmInference != null
        }
    }

    // カメラで撮影
    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            cameraImageUri?.let { uri ->
                val stream = contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(stream)
                selectedBitmap = resizeBitmap(bitmap, 768)
                imageView.setImageBitmap(selectedBitmap)
                analyzeButton.isEnabled = llmInference != null
            }
        }
    }

    // カメラ権限リクエスト
    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera()
        else Toast.makeText(this, "カメラの権限が必要です", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView         = findViewById(R.id.imageView)
        resultText        = findViewById(R.id.resultText)
        promptInput       = findViewById(R.id.promptInput)
        analyzeButton     = findViewById(R.id.analyzeButton)
        selectImageButton = findViewById(R.id.selectImageButton)
        takePicButton     = findViewById(R.id.takePicButton)
        progressBar       = findViewById(R.id.progressBar)
        promptSpinner     = findViewById(R.id.promptSpinner)
        statusText        = findViewById(R.id.statusText)

        setupSpinner()
        analyzeButton.isEnabled = false
        loadModelAsync()

        selectImageButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        takePicButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED
            ) launchCamera()
            else requestCameraPermission.launch(Manifest.permission.CAMERA)
        }

        analyzeButton.setOnClickListener {
            val bitmap = selectedBitmap ?: return@setOnClickListener
            val prompt = promptInput.text.toString().ifBlank { "この画像を詳しく説明してください。" }
            analyzeImageLocally(bitmap, prompt)
        }
    }

    /** LiteRT-LM モデルをバックグラウンドで読み込む */
    private fun loadModelAsync() {
        statusText.text = "⏳ Gemma 4 モデルを読み込み中..."
        progressBar.visibility = View.VISIBLE

        scope.launch {
            try {
                val modelFile = File(MODEL_PATH)
                if (!modelFile.exists()) {
                    statusText.text = "❌ モデルが見つかりません\n→ READMEの adb コマンドを実行してください"
                    progressBar.visibility = View.GONE
                    return@launch
                }

                llmInference = withContext(Dispatchers.IO) {
                    val options = LlmInferenceOptions.builder()
                        .setModelPath(MODEL_PATH)
                        .setMaxTokens(1024)
                        .setTopK(40)
                        .setTemperature(0.4f)
                        .build()
                    LlmInference.createFromOptions(this@MainActivity, options)
                }

                statusText.text = "✅ Gemma 4 E2B 準備完了（完全オフライン）"
                progressBar.visibility = View.GONE
                if (selectedBitmap != null) analyzeButton.isEnabled = true

            } catch (e: Exception) {
                statusText.text = "❌ 読み込みエラー: ${e.message}"
                progressBar.visibility = View.GONE
            }
        }
    }

    /** ローカル推論で画像を分析（インターネット不使用） */
    private fun analyzeImageLocally(bitmap: Bitmap, prompt: String) {
        val inference = llmInference ?: return
        progressBar.visibility = View.VISIBLE
        analyzeButton.isEnabled = false
        resultText.text = "🤔 Gemma 4 が分析中（ローカル処理）..."

        scope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    val imageBytes = bitmapToByteArray(bitmap)
                    val fullPrompt = buildGemma4Prompt(prompt)
                    inference.generateResponse(fullPrompt, imageBytes)
                }
                resultText.text = result
            } catch (e: Exception) {
                resultText.text = "エラー: ${e.message}"
            } finally {
                progressBar.visibility = View.GONE
                analyzeButton.isEnabled = true
            }
        }
    }

    /** Gemma 4 のチャットテンプレート形式でプロンプトを整形 */
    private fun buildGemma4Prompt(userPrompt: String): String =
        "<start_of_turn>user\n<image>\n$userPrompt<end_of_turn>\n<start_of_turn>model\n"

    private fun bitmapToByteArray(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return stream.toByteArray()
    }

    private fun resizeBitmap(bitmap: Bitmap, maxSize: Int): Bitmap {
        val ratio = minOf(maxSize.toFloat() / bitmap.width, maxSize.toFloat() / bitmap.height)
        return if (ratio < 1f)
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * ratio).toInt(),
                (bitmap.height * ratio).toInt(),
                true
            )
        else bitmap
    }

    private fun launchCamera() {
        val file = File.createTempFile("camera_", ".jpg", cacheDir)
        cameraImageUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        takePictureLauncher.launch(cameraImageUri)
    }

    private fun setupSpinner() {
        val presets = arrayOf(
            "この画像を詳しく説明してください。",
            "画像に写っているものを全て列挙してください。",
            "画像内のテキストを読み取ってください（OCR）。",
            "この料理の名前と材料を教えてください。",
            "この植物・動物の種類を特定してください。",
            "画像の問題点・異常を指摘してください。",
            "カスタム入力 →"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        promptSpinner.adapter = adapter
        promptSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>, v: View?, pos: Int, id: Long) {
                if (pos < presets.size - 1) promptInput.setText(presets[pos])
                else { promptInput.setText(""); promptInput.requestFocus() }
            }
            override fun onNothingSelected(p: AdapterView<*>) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        llmInference?.close()
    }
}
