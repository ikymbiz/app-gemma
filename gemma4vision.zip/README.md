# Gemma 4 Vision — 完全ローカル動作 Android アプリ

APIキー不要・インターネット不要。Gemma 4 が Android 端末の中で直接動く画像認識アプリです。

---

## GitHub Actions でビルドする（推奨）

### Option A: ZIP をそのまま push

1. GitHub で新規リポジトリを作成
2. `gemma4vision.zip` をリポジトリのルートに置いて push
   ```bash
   git init
   git add gemma4vision.zip
   git commit -m "init"
   git remote add origin https://github.com/あなた/gemma4vision.git
   git push -u origin main
   ```
3. Actions タブ → ビルド完了後 **Artifacts** から `app-debug.apk` をダウンロード

### Option B: 展開済みファイルを push

```bash
git init && git add . && git commit -m "init"
git remote add origin https://github.com/あなた/gemma4vision.git
git push -u origin main
```

### リリース APK を作りたい場合

```bash
git tag v1.0.0
git push origin v1.0.0
```
→ GitHub Releases に APK が自動公開されます。

---

## ローカルでビルドする

```bash
unzip gemma4vision.zip   # すでに展開済みなら不要
./gradlew assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
```

---

## モデルのセットアップ（アプリ実行前に必要）

### Step 1: モデルをダウンロード（約 2.5GB）

```bash
pip install huggingface_hub
huggingface-cli download \
  litert-community/gemma-4-E2B-it-litert-lm \
  gemma-4-E2B-it.litertlm \
  --local-dir ./model
```

### Step 2: 端末に転送

```bash
adb shell mkdir -p /data/local/tmp/llm/
adb push ./model/gemma-4-E2B-it.litertlm /data/local/tmp/llm/
# 確認
adb shell ls -lh /data/local/tmp/llm/
```

---

## 必要スペック

| モデル | RAM | ストレージ |
|--------|-----|-----------|
| E2B（本アプリ） | 8GB 以上 | 約 2.5GB |
| E4B（高精度版） | 12GB 以上 | 約 5GB |

Android 8.0 (API 26) 以上。エミュレータ（CPU推論）でも動作します。

---

## プロジェクト構成

```
gemma4vision/
├── .github/workflows/
│   ├── build.yml      # push 時に自動ビルド（4層防御）
│   └── release.yml    # タグ push で GitHub Release 自動作成
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/.../MainActivity.kt   # LiteRT-LM ローカル推論
│       └── res/layout/activity_main.xml
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew / gradlew.bat
├── build.gradle
├── settings.gradle
└── gradle.properties
```
