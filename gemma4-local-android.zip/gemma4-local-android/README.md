# Gemma 4 Local Vision Chat for Android

Android 端末内で `.litertlm` モデルを実行する、Gemma 4 向けの画像認識＋チャットアプリのテンプレートです。

- API キー不要
- サーバー不要
- 推論ごとの課金なし
- 画像＋テキストのマルチモーダル入力に対応する構成
- GitHub Actions で APK / AAB を生成

> 注意: モデルファイルは巨大なため、このリポジトリには同梱していません。Gemma 4 E2B LiteRT-LM のモデルファイルは約 2.58GB です。アプリ内の「モデル選択」から端末上の `.litertlm` ファイルを選択するか、「URLからモデルをダウンロード」でアプリ内ストレージへ保存してください。

## 推奨モデル

- `litert-community/gemma-4-E2B-it-litert-lm`
- 低〜中スペック端末では E2B を推奨
- E4B 以上は高性能端末向け

Hugging Face のモデルは、ライセンス同意やトークンが必要になる場合があります。その場合は次のいずれかで配置してください。

1. PC で `.litertlm` をダウンロードし、USB / Google Drive / Files アプリなどで Android 端末へ移す
2. アプリの「モデル選択」で `.litertlm` を選択してアプリ内ストレージへコピーする
3. 直接ダウンロード URL と必要に応じて Hugging Face token を入力する

## 使い方

1. Android Studio でこのプロジェクトを開く
2. 実機にインストールする
3. `.litertlm` モデルを選択、または URL からダウンロード
4. 「読み込み」を押す
5. テキスト質問、または画像選択後に質問する

## GitHub Actions

`.github/workflows/android-build.yml` を同梱しています。

- `main` への push / PR で Debug APK と Release AAB をビルド
- `v1.0.0` のようなタグを push すると GitHub Release に成果物を添付

```bash
git init
git add .
git commit -m "Initial on-device Gemma 4 Android app"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main

git tag v1.0.0
git push origin v1.0.0
```

## 本番公開時の注意

`app/build.gradle.kts` では、GitHub Actions で成果物を作れるように release ビルドへ debug 署名を使っています。Google Play に出す場合は、必ず本番用 keystore に差し替えてください。

## 端末要件の目安

- Android 9 以上
- RAM 8GB 以上を推奨
- Gemma 4 E2B でもモデルファイルは数GB級
- GPU バックエンドは対応端末のみ。動かない場合はアプリ内スイッチを OFF にして CPU で読み込んでください。

## 主なファイル

```text
app/src/main/java/com/example/gemma4local/MainActivity.kt
app/src/main/java/com/example/gemma4local/OnDeviceGemmaRunner.kt
app/src/main/java/com/example/gemma4local/FileStore.kt
.github/workflows/android-build.yml
```

## 実装メモ

- `OnDeviceGemmaRunner.kt` が LiteRT-LM の `Engine` と `Conversation` を管理します。
- 画像を選択した場合は、`Content.ImageFile` と `Content.Text` をまとめて送信します。
- モデルファイルや画像は、アプリ内ストレージ・キャッシュへコピーしてから推論に使います。
