package com.example.gemma4local

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.withContext
import java.io.Closeable

/**
 * Thin wrapper around LiteRT-LM.
 *
 * The app does not call a cloud endpoint. All model execution happens through a local
 * .litertlm file stored in app-private storage, or another readable file path copied there.
 */
class OnDeviceGemmaRunner(private val context: Context) : Closeable {
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    val isLoaded: Boolean
        get() = engine != null && conversation != null

    suspend fun loadModel(
        modelPath: String,
        useGpu: Boolean,
        systemInstruction: String = DEFAULT_SYSTEM_INSTRUCTION,
    ) = withContext(Dispatchers.Default) {
        close()

        val mainBackend = if (useGpu) Backend.GPU() else Backend.CPU()
        val visionBackend = if (useGpu) Backend.GPU() else Backend.CPU()

        val engineConfig = EngineConfig(
            modelPath = modelPath,
            backend = mainBackend,
            visionBackend = visionBackend,
            cacheDir = context.cacheDir.absolutePath,
        )

        val newEngine = Engine(engineConfig)
        newEngine.initialize()

        val conversationConfig = ConversationConfig(
            systemInstruction = Contents.of(systemInstruction),
            samplerConfig = SamplerConfig(
                topK = 40,
                topP = 0.95,
                temperature = 0.7,
            ),
        )

        engine = newEngine
        conversation = newEngine.createConversation(conversationConfig)
    }

    suspend fun resetConversation(systemInstruction: String = DEFAULT_SYSTEM_INSTRUCTION) = withContext(Dispatchers.Default) {
        val currentEngine = engine ?: return@withContext
        conversation?.close()
        conversation = currentEngine.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(systemInstruction),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.7),
            ),
        )
    }

    suspend fun sendMessage(
        prompt: String,
        imagePath: String?,
        onPartial: suspend (String) -> Unit,
    ) = withContext(Dispatchers.Default) {
        val currentConversation = conversation
            ?: error("モデルが読み込まれていません。先に .litertlm モデルを読み込んでください。")

        val contents = if (imagePath.isNullOrBlank()) {
            Contents.of(prompt)
        } else {
            Contents.of(
                Content.ImageFile(imagePath),
                Content.Text(prompt),
            )
        }

        currentConversation
            .sendMessageAsync(contents)
            .catch { throwable -> onPartial("\n[ERROR] ${throwable.message ?: throwable.javaClass.simpleName}") }
            .collect { message ->
                val text = message.text.ifBlank { message.toString() }
                onPartial(text)
            }
    }

    override fun close() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
    }

    companion object {
        const val DEFAULT_SYSTEM_INSTRUCTION =
            "あなたはAndroid端末内で実行される日本語対応のアシスタントです。" +
                "画像が渡された場合は、画像の内容を丁寧に観察して回答してください。" +
                "わからないことは推測しすぎず、確認が必要だと伝えてください。"
    }
}
